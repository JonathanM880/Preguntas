package com.progavanzada.deber3;

import android.content.Context;
import android.opengl.GLSurfaceView;
import android.view.GestureDetector;
import android.view.MotionEvent;
import android.view.ScaleGestureDetector;

public class MyGLSurfaceView extends GLSurfaceView {
    private final MyGLRenderer renderer;
    private GestureDetector gestureDetector;
    private ScaleGestureDetector scaleGestureDetector;

    public MyGLSurfaceView(Context context) {
        super(context);

        setEGLContextClientVersion(2);

        renderer = new MyGLRenderer();
        setRenderer(renderer);
        // Inicializar GestureDetector para scroll y taps
        gestureDetector = new GestureDetector(context, new GestureDetector.SimpleOnGestureListener() {
            @Override
            public boolean onScroll(MotionEvent e1, MotionEvent e2, float distanceX, float distanceY) {
                // Mover cilindro con gesto horizontal
                float moveX = -distanceX / 100f;
                renderer.moveCilindro(moveX);

                // Rotar rombo con gesto horizontal (Y) y vertical (X)
                float rotateY = -distanceX / 5f;
                float rotateX = -distanceY / 5f;
                renderer.rotateRombo(rotateY, rotateX);

                return true;
            }
        });

        // Inicializar ScaleGestureDetector para zoom (esfera)
        scaleGestureDetector = new ScaleGestureDetector(context,
                new ScaleGestureDetector.SimpleOnScaleGestureListener(){
            @Override
            public boolean onScale(ScaleGestureDetector detector) {
                float scaleFactor = detector.getScaleFactor();
                renderer.scaleSphere(scaleFactor);
                return true;
            }
        });
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        boolean handled = scaleGestureDetector.onTouchEvent(event);
        handled = gestureDetector.onTouchEvent(event) || handled;
        return handled || super.onTouchEvent(event);
    }
}
