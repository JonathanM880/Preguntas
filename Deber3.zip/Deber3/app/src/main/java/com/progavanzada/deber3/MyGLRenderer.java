package com.progavanzada.deber3;


import android.opengl.GLES20;
import android.opengl.GLSurfaceView;
import android.opengl.Matrix;

import javax.microedition.khronos.egl.EGLConfig;
import javax.microedition.khronos.opengles.GL10;

public class MyGLRenderer implements GLSurfaceView.Renderer {

    private final float[] mProjectionMatrix = new float[16];
    private final float[] mViewMatrix = new float[16];
    private final float[] mVPMatrix = new float[16];
    private final float[] mModelMatrix = new float[16];

    private Sphere esfera;
    private Cilindro cilindro;
    private Rombo rombo;
    private float cilindroPosX = 0f;
    private float romboAngleX = 0f;
    private float romboAngleY = 0f;
    private float sphereScale = 1f;

    // Método para mover cilindro desde gestos
    public void moveCilindro(float deltaX) {
        cilindroPosX += deltaX;
        // límites opcionales para que no se salga
        cilindroPosX = Math.max(-1f, Math.min(1f, cilindroPosX));
    }

    // Método para rotar torus desde gestos
    public void rotateRombo(float deltaX, float deltaY) {
        romboAngleY += deltaX;
        romboAngleX += deltaY;

        romboAngleY %= 360;
        romboAngleX %= 360;

    }

    // Método para escalar esfera desde gestos
    public void scaleSphere(float scaleFactor) {
        sphereScale *= scaleFactor;
        sphereScale = Math.max(0.1f, Math.min(3f, sphereScale));
    }

    @Override
    public void onSurfaceCreated(GL10 gl10, EGLConfig eglConfig) {
        GLES20.glClearColor(0.0f, 0.0f, 0.0f, 1.0f);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST);

        cilindro= new Cilindro(40, 0.5f, 0.75f);
        cilindro.setColorPart("all", new float[]{0.969f, 0.773f, 0.624f, 1.0f});

        esfera = new Sphere(0.25f, 30, 30);
        esfera.setColor(new float[]{0.478f, 0.720f, 0.624f, 1.0f});

        rombo = new Rombo();

    }

    @Override
    public void onSurfaceChanged(GL10 gl10, int width, int height) {
        GLES20.glClearColor(0.176f, 0.106f, 0.278f, 1.0f);
        GLES20.glEnable(GLES20.GL_DEPTH_TEST); // ¡Habilita el test de profundidad!

        GLES20.glViewport(0, 0, width, height);

        float ratio = (float) width / height;
        Matrix.frustumM(mProjectionMatrix, 0, -ratio, ratio, -1, 1, 1, 10);
    }

    @Override
    public void onDrawFrame(GL10 gl10) {
        GLES20.glClear(GLES20.GL_COLOR_BUFFER_BIT | GLES20.GL_DEPTH_BUFFER_BIT);

        // Configuramos la cámara
        Matrix.setLookAtM(
                mViewMatrix, 0,
                0f, 0f, 4f,  // posición de la cámara
                0.0f, 0f, 0.0f,  // punto al que mira
                0.0f, 1.0f, 0.0f   // vector up
        );

        // Multiplicamos proyección * vista para tener la matriz VP
        Matrix.multiplyMM(mVPMatrix, 0, mProjectionMatrix, 0, mViewMatrix, 0);

        float[] mvMatrix = new float[16];

        // DIBUJAR CILINDRO CON TRASLACIÓN SEGÚN GESTO
        Matrix.setIdentityM(mModelMatrix, 0);
        Matrix.translateM(mModelMatrix, 0, cilindroPosX, 0f, 0);

        Matrix.multiplyMM(mvMatrix, 0, mViewMatrix, 0, mModelMatrix, 0);
        Matrix.multiplyMM(mVPMatrix, 0, mProjectionMatrix, 0, mvMatrix, 0);

        cilindro.draw(mVPMatrix);

        // DIBUJAR ESFERA CON ESCALA SEGÚN GESTO
        Matrix.setIdentityM(mModelMatrix, 0);
        Matrix.translateM(mModelMatrix, 0, 0, 2.5f, 0);
        Matrix.scaleM(mModelMatrix, 0, sphereScale, sphereScale, sphereScale);

        Matrix.multiplyMM(mvMatrix, 0, mViewMatrix, 0, mModelMatrix, 0);
        Matrix.multiplyMM(mVPMatrix, 0, mProjectionMatrix, 0, mvMatrix, 0);

        esfera.draw(mVPMatrix);

        // DIBUJAR ROMBO CON ROTACIÓN SEGÚN GESTO
        Matrix.setIdentityM(mModelMatrix, 0);
        Matrix.translateM(mModelMatrix, 0, 0f, -2.5f, 0f);
        Matrix.scaleM(mModelMatrix, 0,0.25f,.45f,.45f);
        Matrix.rotateM(mModelMatrix, 0, romboAngleX, 1f, 0f, 0f); // X
        Matrix.rotateM(mModelMatrix, 0, romboAngleY, 0f, 1f, 0f); // Y

        Matrix.multiplyMM(mvMatrix, 0, mViewMatrix, 0, mModelMatrix, 0);
        Matrix.multiplyMM(mVPMatrix, 0, mProjectionMatrix, 0, mvMatrix, 0);

        rombo.draw(mVPMatrix);


    }

    public static int loadShader(int type, String shaderCode) {
        int shader = GLES20.glCreateShader(type);
        GLES20.glShaderSource(shader, shaderCode);
        GLES20.glCompileShader(shader);
        return shader;
    }
}
